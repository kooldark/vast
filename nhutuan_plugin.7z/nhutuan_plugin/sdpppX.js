global.sdpppX = {
}